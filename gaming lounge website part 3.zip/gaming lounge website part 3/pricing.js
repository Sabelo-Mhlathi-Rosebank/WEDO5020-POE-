
let platformSelect = document.getElementById('calc-platform');
let hoursInput = document.getElementById('calc-hours');
let calcTotal = document.getElementById('calc-total');

function calculateCost() {
    let ratePerHour = parseFloat(platformSelect.value);
    let hours = parseFloat(hoursInput.value);

    if (!ratePerHour || !hours || hours <= 0) {
        calcTotal.textContent = 'R0';
        return;
    }

    let total = ratePerHour * 2 * hours;
    calcTotal.textContent = 'R' + total.toFixed(2);
}

platformSelect.addEventListener('change', calculateCost);
hoursInput.addEventListener('input', calculateCost);

let accordionBtns = document.querySelectorAll('.accordion-btn');

accordionBtns.forEach(function(btn) {
    btn.addEventListener('click', function() {
        let content = this.nextElementSibling;
        let isActive = this.classList.contains('active');

        accordionBtns.forEach(function(otherBtn) {
            otherBtn.classList.remove('active');
            otherBtn.nextElementSibling.style.display = 'none';
        });

        if (!isActive) {
            this.classList.add('active');
            content.style.display = 'block';
        }
    });
});

let rates = {
    'Console': 20,
    'PC': 30
};

function updateSessionSummary() {
    let platform = document.getElementById('sb-platform').value;
    let game = document.getElementById('sb-game').value;
    let duration = parseFloat(document.getElementById('sb-duration').value);
    let players = parseInt(document.getElementById('sb-players').value);

    document.getElementById('sb-platform-display').textContent = platform || '-';
    document.getElementById('sb-game-display').textContent = game || '-';
    document.getElementById('sb-duration-display').textContent = 
        duration ? duration + ' hour(s)' : '-';
    document.getElementById('sb-players-display').textContent = players || '-';

    if (platform && duration && players) {
        let ratePerHalfHour = rates[platform];
        let total = ratePerHalfHour * 2 * duration * players;
        document.getElementById('sb-total').textContent = 'R' + total.toFixed(2);
    } else {
        document.getElementById('sb-total').textContent = 'R0';
    }
}

document.getElementById('sb-platform').addEventListener('change', updateSessionSummary);
document.getElementById('sb-game').addEventListener('change', updateSessionSummary);
document.getElementById('sb-duration').addEventListener('change', updateSessionSummary);
document.getElementById('sb-players').addEventListener('input', updateSessionSummary);

document.getElementById('sb-add').addEventListener('click', function() {
    let platform = document.getElementById('sb-platform').value;
    let game = document.getElementById('sb-game').value;
    let duration = parseFloat(document.getElementById('sb-duration').value);
    let players = parseInt(document.getElementById('sb-players').value);

    if (!platform || !game || !duration || !players) {
        alert('Please fill in all session details before adding.');
        return;
    }

    let ratePerHalfHour = rates[platform];
    let total = ratePerHalfHour * 2 * duration * players;

    let session = {
        platform: platform,
        game: game,
        duration: duration,
        players: players,
        total: total
    };

    let sessions = JSON.parse(localStorage.getItem('sessionCart')) || [];
    sessions.push(session);
    localStorage.setItem('sessionCart', JSON.stringify(sessions));

    loadSessionCart();
});

function loadSessionCart() {
    let sessions = JSON.parse(localStorage.getItem('sessionCart')) || [];
    let list = document.getElementById('session-items');
    let actions = document.getElementById('session-actions');
    let totalDisplay = document.getElementById('session-total-display');
    list.innerHTML = '';

    if (sessions.length === 0) {
        list.innerHTML = '<li style="justify-content:center;">No sessions added yet.</li>';
        actions.style.display = 'none';
        totalDisplay.textContent = '';
        return;
    }

    let grandTotal = 0;

    sessions.forEach(function(session, index) {
        grandTotal += session.total;
        let li = document.createElement('li');
        li.innerHTML = `
            <span>
                ${session.game} | ${session.platform} | 
                ${session.duration}hr(s) | ${session.players} player(s) | 
                <strong>R${session.total.toFixed(2)}</strong>
            </span>
            <button onclick="removeSession(${index})"
            style="background:transparent; border:none;
            color:rgb(255,80,80); cursor:pointer;
            font-size:1rem;">✕</button>
        `;
        list.appendChild(li);
    });

    totalDisplay.textContent = 'Grand Total: R' + grandTotal.toFixed(2);
    actions.style.display = 'flex';

    localStorage.setItem('sessionTotal', grandTotal.toFixed(2));
    
    localStorage.setItem('sessionDetails', JSON.stringify(sessions[0]));
}

function removeSession(index) {
    let sessions = JSON.parse(localStorage.getItem('sessionCart')) || [];
    sessions.splice(index, 1);
    localStorage.setItem('sessionCart', JSON.stringify(sessions));
    loadSessionCart();
}

document.getElementById('clear-session').addEventListener('click', function() {
    localStorage.removeItem('sessionCart');
    localStorage.removeItem('sessionTotal');
    localStorage.removeItem('sessionDetails');
    loadSessionCart();
});

loadSessionCart();