
let siteContent = [
    {
        title: 'Home',
        url: 'index.html',
        keywords: ['home', 'gaming lounge', 'diepkloof', 'soweto', 
                   'level up', 'experience', 'tournament'],
        description: 'Welcome to Diepkloof Gaming Lounge. High performance gaming in Soweto.'
    },
    {
        title: 'FPS Games',
        url: 'games.html',
        keywords: ['fps', 'warzone', 'fortnite', 'apex legends', 
                   'counter strike', 'valorant', 'call of duty'],
        description: 'Play top FPS games including Warzone, Fortnite, Apex Legends and more.'
    },
    {
        title: 'Esports Games',
        url: 'games.html',
        keywords: ['esports', 'fifa', 'ea sports', 'efootball', 
                   'rocket league', 'madden', 'ufc'],
        description: 'Compete in esports titles including EA Sports FC, Rocket League and more.'
    },
    {
        title: 'PC Gaming',
        url: 'games.html',
        keywords: ['pc', 'computer', 'gaming pc', 'high end pc'],
        description: 'High end PC gaming available at Diepkloof Gaming Lounge.'
    },
    {
        title: 'Console Gaming',
        url: 'games.html',
        keywords: ['console', 'playstation', 'xbox', 'ps5'],
        description: 'PlayStation and Xbox console gaming available.'
    },
    {
        title: 'Pricing and Rates',
        url: 'pricing.html',
        keywords: ['price', 'pricing', 'rates', 'cost', 'r20', 
                   'r30', 'r50', 'r60', 'affordable'],
        description: 'Console from R20 per 30 minutes. PC from R30 per 30 minutes.'
    },
    {
        title: 'Group Packages',
        url: 'pricing.html',
        keywords: ['group', 'duo', 'trio', 'squad', 'package', 
                   'deal', 'friends'],
        description: 'Group packages including Duo Deal, Trio Deal and Squad Deal.'
    },
    {
        title: 'Membership Plans',
        url: 'pricing.html',
        keywords: ['membership', 'bronze', 'silver', 'gold', 
                   'monthly', 'plan', 'subscribe'],
        description: 'Bronze, Silver and Gold membership plans available.'
    },
    {
        title: 'Weekend Specials',
        url: 'pricing.html',
        keywords: ['weekend', 'special', 'discount', 'snacks', 
                   'drinks', '50% off'],
        description: 'Enjoy 50% off snacks and drinks every weekend.'
    },
    {
        title: 'Contact Us',
        url: 'contact.html',
        keywords: ['contact', 'phone', 'email', 'address', 
                   'location', 'find us', '067'],
        description: 'Contact Diepkloof Gaming Lounge. Phone: 067 834 8085.'
    },
    {
        title: 'Opening Hours',
        url: 'contact.html',
        keywords: ['hours', 'opening', 'times', 'monday', 
                   'friday', 'saturday', 'sunday', 'open'],
        description: 'Open Monday to Friday 12:00-22:00. Saturday to Sunday 10:00-00:00.'
    },
    {
        title: 'Book a Session',
        url: 'form.html',
        keywords: ['book', 'booking', 'reserve', 'session', 
                   'register', 'sign up'],
        description: 'Book your gaming session at Diepkloof Gaming Lounge.'
    },
    {
        title: 'Tournament',
        url: 'index.html',
        keywords: ['tournament', 'compete', 'competition', 
                   'register', 'prize'],
        description: 'Register for the next gaming tournament at Diepkloof Gaming Lounge.'
    }
];

let params = new URLSearchParams(window.location.search);
let query = params.get('q');

let queryDisplay = document.getElementById('search-query-display');
let resultsContainer = document.getElementById('search-results');

if (!query || query.trim() === '') {
    queryDisplay.textContent = 'Please enter a search term.';
    resultsContainer.innerHTML = '';
} else {
    queryDisplay.textContent = 'Showing results for: "' + query + '"';

    let searchTerm = query.toLowerCase().trim();
    let matches = siteContent.filter(function(item) {
        return item.title.toLowerCase().includes(searchTerm) ||
               item.description.toLowerCase().includes(searchTerm) ||
               item.keywords.some(function(keyword) {
                   return keyword.includes(searchTerm);
               });
    });

    if (matches.length === 0) {
        resultsContainer.innerHTML = `
            <div style="text-align:center; padding: 2rem;">
                <p>No results found for "${query}".</p>
                <p style="color:#cccccc; margin-top:1rem;">
                Try searching for games, pricing, booking or contact.
                </p>
                <a href="index.html" class="btn" 
                style="margin-top:1.5rem;">Back to Home</a>
            </div>
        `;
    } else {
        let html = '<div class="offer-container">';
        matches.forEach(function(item) {
            html += `
                <div class="offer">
                    <h3>${item.title}</h3>
                    <p>${item.description}</p>
                    <br>
                    <a href="${item.url}" class="btn">View Page</a>
                </div>
            `;
        });
        html += '</div>';
        resultsContainer.innerHTML = html;
    }
}