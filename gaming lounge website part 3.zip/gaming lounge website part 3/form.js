
window.addEventListener('load', function() {
    let sessionDetails = JSON.parse(localStorage.getItem('sessionDetails'));
    let sessionTotal = localStorage.getItem('sessionTotal');

    if (sessionDetails) {
        let platformRadio = document.querySelector(
            `input[name="platform"][value="${sessionDetails.platform}"]`
        );
        if (platformRadio) platformRadio.checked = true;

        let playersField = document.getElementById('players');
        if (playersField) playersField.value = sessionDetails.players;

        let messageField = document.getElementById('message');
        if (messageField) {
            messageField.value = 
                `Game: ${sessionDetails.game} | ` +
                `Duration: ${sessionDetails.duration} hour(s) | ` +
                `Total: R${sessionTotal}`;
        }
    }
});

const SERVICE_ID = 'service_5qz8hic';
const TEMPLATE_ID = 'template_u7kiw7g';
const PUBLIC_KEY = 'WP7yuyLW0f8_yCy2W';

document.getElementById('booking-form').addEventListener('submit', function(event) {
    event.preventDefault();

    let errors = document.querySelectorAll('.error-message');
    errors.forEach(function(error) {
        error.remove();
    });

    let isValid = true;

    let name = document.getElementById('name').value.trim();
    if (name === '') {
        showError('name', 'Please enter your name');
        isValid = false;
    } else if (name.length < 2) {
        showError('name', 'Name must be at least 2 characters');
        isValid = false;
    }

    let email = document.getElementById('email').value.trim();
    let emailFormat = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (email === '') {
        showError('email', 'Please enter your email');
        isValid = false;
    } else if (!emailFormat.test(email)) {
        showError('email', 'Please enter a valid email address');
        isValid = false;
    }

    let phone = document.getElementById('phone').value.trim();
    let phoneFormat = /^[0-9]{10}$/;
    if (phone === '') {
        showError('phone', 'Please enter your phone number');
        isValid = false;
    } else if (!phoneFormat.test(phone)) {
        showError('phone', 'Please enter a valid 10 digit phone number');
        isValid = false;
    }

    let date = document.getElementById('date').value;
    if (date === '') {
        showError('date', 'Please select a preferred date');
        isValid = false;
    }

    let time = document.getElementById('time').value;
    if (time === '') {
        showError('time', 'Please select a preferred time');
        isValid = false;
    }

    let players = document.getElementById('players').value;
    if (players === '') {
        showError('players', 'Please enter number of players');
        isValid = false;
    } else if (players < 1 || players > 20) {
        showError('players', 'Number of players must be between 1 and 20');
        isValid = false;
    }

    let platform = document.querySelector('input[name="platform"]:checked');
    if (!platform) {
        showError('platform-group', 'Please select a platform');
        isValid = false;
    }

    let gender = document.querySelector('input[name="gender"]:checked');
    if (!gender) {
        showError('gender-group', 'Please select your gender');
        isValid = false;
    }

    if (isValid) {
        emailjs.sendForm(SERVICE_ID, TEMPLATE_ID, this, PUBLIC_KEY)
            .then(function() {
                document.getElementById('booking-response').innerHTML = `
                    <div class="success-message">
                        <h2>Booking Request Received!</h2>
                        <p>Thank you for booking with Diepkloof Gaming Lounge.</p>
                        <p>We will contact you shortly to confirm your session.</p>
                        <a href="index.html" class="btn">Back to Home</a>
                    </div>
                `;
                document.getElementById('booking-form').reset();
            })
            .catch(function(error) {
                document.getElementById('booking-response').innerHTML = `
                    <div class="error-message">
                        <p>Something went wrong. Please try again.</p>
                    </div>
                `;
                console.error('EmailJS error:', error);
            });
    }
});

function showError(fieldId, message) {
    let field = document.getElementById(fieldId);
    if (field) {
        let error = document.createElement('p');
        error.className = 'error-message';
        error.textContent = message;
        field.parentElement.appendChild(error);
    }
}